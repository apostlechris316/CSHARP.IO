﻿/********************************************************************************
 * CSHARP IO Library - General utility to manipulate files in on the Windows 
 * file system 
 * 
 * NOTE: Adapted from Clinch.IO
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 *
 * CHANGES: 
 * 
 *  - v8.0.1.0 - Removed dependency on FileHelper
 *  - v5.0 - All methods converted to static
 *  - v5.0 - Namespace changed to contain version for future backwards compatability.
 *  
 * FUTURE IMPROVEMENTS:
 * 
 *          
 ********************************************************************************/

namespace CSHARP.V8.Helpers.IO
{
    using System;
    using System.IO;

    /// <summary>
    /// Binary File Helper Functions
    /// </summary>
    public static class BinaryFileHelperStatic
    {
        /// <summary>
        /// Reads the full contents of the file to a byte array
        /// </summary>
        /// <param name="fileName">name of file to get contents from</param>
        /// <returns>Array of bytes containing the content or null if there is not contents</returns>
        /// <remarks>
        /// v8.0.1.0 - Now uses System.IO.File.ReadAllBytes()
        /// v1.0.1.1 - ReadContents needs to initialize the byte array before passing to File.OpenRead</remarks.>
        public static byte[]? ReadContents(string fileName)
        {
            if (string.IsNullOrEmpty(fileName)) throw new ArgumentNullException(nameof(fileName));
            if (File.Exists(fileName) == false) throw new FileNotFoundException("The file (" + fileName + ") does not exist");

            return File.ReadAllBytes(fileName);
        }

        /// <param name="fileName">name of file to get contents from</param>
        /// <returns>FileStream object</returns>
        /// <remarks>V1.0.0.3 - New method</remarks>
        public static FileStream ReadStream(string fileName)
        {
            if (string.IsNullOrEmpty(fileName)) throw new ArgumentNullException(nameof(fileName));
            if (File.Exists(fileName) == false) throw new FileNotFoundException("The file (" + fileName + ") does not exist");

            return File.OpenRead(fileName);
        }

        /// <summary>
        /// Writes the contents supplied to a file.
        /// </summary>
        /// <param name="fileName">file to write contents to</param>
        /// <param name="contents">contents to write</param>
        /// <remarks>v8.0.1.0 Now uses System.IO.WriteAllBytes however ensures the directory exists first</remarks>
        public static void WriteContents(string fileName, byte [] contents)
        {
            if (string.IsNullOrEmpty(fileName)) throw new ArgumentNullException(nameof(fileName));
            if (contents == null) throw new ArgumentNullException(nameof(contents));

            // ensure the directory exists
            var fileDirectory = string.Empty;
            var fileParts = fileName.Split('\\');
            for(var partNdx = 1; partNdx < fileParts.Length-1; partNdx++)
            {
                fileDirectory = fileDirectory + "\\" + fileParts[partNdx];
            }
            Directory.CreateDirectory(fileDirectory);

            File.WriteAllBytes(fileName, contents);
        }
    }
}
