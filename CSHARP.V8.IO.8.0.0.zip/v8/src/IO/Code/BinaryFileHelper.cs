﻿/********************************************************************************
 * CSHARP IO Library - General utility to manipulate files in on the Windows 
 * file system 
 * 
 * NOTE: Adapted from Clinch.IO
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 *
 * CHANGES: 
 * 
 *  - (v5.0) Namespace changed to contain version for future backwards compatability.
 *  - (v5.0) All methods converted to static
 *  
 * FUTURE IMPROVEMENTS:
 * 
 *  - Remove dependency on FileHelper
 *          
 ********************************************************************************/

namespace CSHARP.V8.Helpers.IO
{
    using System;
    using System.IO;

    /// <summary>
    /// Binary File Helper Functions
    /// </summary>
    public class BinaryFileHelper
    {
        /// <summary>
        /// Reads the full contents of the file to a byte array
        /// </summary>
        /// <param name="fileName">name of file to get contents from</param>
        /// <returns>Array of bytes containing the content or null if there is not contents</returns>
        /// <remarks>
        /// v8.0.1.0 - Now uses System.IO.File.ReadAllBytes()
        /// v1.0.1.1 - ReadContents needs to initialize the byte array before passing to File.OpenRead</remarks.>
        public byte[]? ReadContents(string fileName)
        {
            return ReadContents(fileName);
        }
        /// <summary>
        /// Opens the file and returns the stream to be read from
        /// </summary>
        /// <param name="fileName">name of file to get contents from</param>
        /// <returns>FileStream object</returns>
        /// <remarks>V1.0.0.3 - New method</remarks>
        public FileStream ReadStream(string fileName)
        {
            return BinaryFileHelperStatic.ReadStream(fileName);
        }
        /// <summary>
        /// Writes the contents supplied to a file.
        /// </summary>
        /// <param name="fileName">file to write contents to</param>
        /// <param name="contents">contents to write</param>
        /// <remarks>v8.0.1.0 Now uses System.IO.WriteAllBytes however ensures the directory exists first</remarks>
        public static void WriteContents(string fileName, byte [] contents)
        {
            BinaryFileHelperStatic.WriteContents(fileName, contents);
        }
    }
}
