﻿/********************************************************************************
 * CSHARP IO Library - General utility to manipulate files in on the Windows 
 * file system 
 * 
 * NOTE: Adapted from Clinch.IO
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 *
 * CHANGES: 
 * 
 *  (v5.0) 
 *      - Namespace changed to contain version for future backwards compatability.
 *      - All methods converted to static
 *  (v8.0) 
 *      - CopyDirectory introduces ignoreFileExistErrorIfNotOverwriting. If not overwriting now allows to skip file rather than throwing an error for it existing
 *      
 *  
 * FUTURE IMPROVEMENTS:
 * 
 * - CopyFiles 
 *      - More of this functionality is available in System.IO so these functions could get smaller or disappear
 * - CopyDirectory
 *      - More of this functionality is available in System.IO so these functions could get smaller or disappear
 * 
 *********************************************************************************/

namespace CSHARP.V8.Helpers.IO
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    /// <summary>
    /// C# Class containing Static Methods to help working with files and file paths.
    /// </summary>
    public static class FileHelperStatic
    {
        /// <summary>
        /// Look at all files in a given folder to see if they could have been new or edited.
        /// </summary>
        /// <param name="firstFolder">The full path to folder to compare</param>
        /// <param name="secondFolder">The full path to the folder you want compared with the firstFolder</param>
        /// <param name="recursive">Checks all subdirectories in both folders against each other</param>
        /// <param name="checkContents">If selected compares the actual contents of the file if the lengths match otherwise just does quick check of date, file meta and size check.</param>
        /// <returns></returns>
        /// <remarks> NEW IN v1.0.0.13
        /// If you pass checkContents of false, then the results may not be totally accurrate
        /// v1.0.1.0 
        ///     - Bug Fix on checkContents boolean it was using reverse logic. This is now resovled so you will need to resolve your code.
        ///     - Now checks subdirectories if recursive = true
        /// </remarks>
        public static Dictionary<FileInfo, string> GetPossibleNewOrEditedFilesInFolders(string firstFolder, string secondFolder, bool recursive, bool checkContents)
        {
            if (string.IsNullOrEmpty(firstFolder)) throw new ArgumentNullException(nameof(firstFolder));
            if (string.IsNullOrEmpty(secondFolder)) throw new ArgumentNullException(nameof(secondFolder));

            var results = new Dictionary<FileInfo, string>();

            var filesFirstInDirectory = GetFileListForDirectory(firstFolder);
            var filesInSecondDirectory = GetFileListForDirectory(secondFolder);

            foreach (FileInfo fileInfo in filesFirstInDirectory)
            {
                var secondFileInfo = filesInSecondDirectory.FirstOrDefault(f => f.Name == fileInfo.Name);
                if (secondFileInfo == null)
                {
                    // TO DO: Check if file already in results
                    results.Add(fileInfo, "NEW");
                }
                else
                {
                    // if the size is different no need to check there is a difference
                    if (secondFileInfo.Length != fileInfo.Length)
                    {
                        results.Add(fileInfo, "EDITED");
                    }
                    else
                    {
                        // v1.0.1.1 - This boolean was wrong in prior versions. Logic is now changed to compare conent if true
                        if (checkContents == true)
                        {
                            // if we need to compare length
                            if (FileCompare(fileInfo.FullName, secondFileInfo.FullName) == false)
                            {
                                results.Add(fileInfo, "EDITED");
                            }
                        }
                    }
                }
            }

            // TO DO: Need to add unit tests for this
            if(recursive)
            {
                var directoriesFirstInDirectory = GetSubDirectories(firstFolder);
                var directoriesSecondInDirectory = GetSubDirectories(secondFolder);

                var directoriesInBoth = new List<DirectoryInfo>();

                // Check if subdirectories in the first exist in the second
                foreach (var directory in directoriesFirstInDirectory)
                {
                    // Check if directory in first exists in second
                    if (directoriesSecondInDirectory.Contains(directory))
                    {
                        // if exists we are calling recursively to check subdiretory files
                        var subDirectoryResults = GetPossibleNewOrEditedFilesInFolders(directory.FullName, directoriesSecondInDirectory.First(x => x.Name == directory.Name).FullName, recursive, checkContents);
                        foreach (var result in subDirectoryResults)
                        {
                            results.Add(result.Key, result.Value);
                        }
                    }
                    else
                    {
                        // Only in first so flag all files as new
                        var filesFirstInSubDirectory = GetFileListForDirectory(firstFolder);
                        foreach (var fileInfo in filesFirstInSubDirectory)
                        {
                            // TO DO: Check if file already in results
                            results.Add(fileInfo, "NEW");
                        }
                    }
                }

                // Check if subdirectories in the second exist in the first
                foreach (var directory in directoriesSecondInDirectory)
                {
                    // Check if directory in first exists in second
                    if (directoriesFirstInDirectory.Contains(directory) == false)
                    {
                        // if does not exist in first then flag all files in second directory as new
                        var filesSecondInSubDirectory = GetFileListForDirectory(directory.FullName);
                        foreach (var fileInfo in filesSecondInSubDirectory)
                        {
                            // TO DO: Check if file already in results
                            results.Add(fileInfo, "NEW");
                        }
                    }
                }
            }

            return results;
        }

        /// <summary>
        /// Compares two files to see if they are equal
        /// </summary>
        /// <param name="firstFilePath">Path to the first file to compare</param>
        /// <param name="secondFilePath">Path to the second file to compare</param>
        /// <returns></returns>
        /// <remarks> NEW IN v1.0.0.13
        public static bool FileCompare(string firstFilePath, string secondFilePath)
        {
            if (string.IsNullOrEmpty(firstFilePath)) throw new ArgumentNullException("ERROR: firstFilePath is required");
            if (string.IsNullOrEmpty(secondFilePath)) throw new ArgumentNullException("ERROR: secondFilePath is required");

            int file1byte;
            int file2byte;
            FileStream fs1;
            FileStream fs2;

            // Determine if the same file was referenced two times.
            if (firstFilePath == secondFilePath)
            {
                // Return true to indicate that the files are the same.
                return true;
            }

            // Open the two files.
            using (fs1 = new FileStream(firstFilePath, FileMode.Open))
            {
                using (fs2 = new FileStream(secondFilePath, FileMode.Open))
                {
                    // Check the file sizes. If they are not the same, the files 
                    // are not the same.
                    if (fs1.Length != fs2.Length)
                    {
                        // Close the file
                        fs1.Close();
                        fs2.Close();

                        // Return false to indicate files are different
                        return false;
                    }

                    // Read and compare a byte from each file until either a
                    // non-matching set of bytes is found or until the end of
                    // file1 is reached.
                    do
                    {
                        // Read one byte from each file.
                        file1byte = fs1.ReadByte();
                        file2byte = fs2.ReadByte();
                    }
                    while ((file1byte == file2byte) && (file1byte != -1));

                    // Close the files.
                    fs1.Close();
                    fs2.Close();

                    // Return the success of the comparison. "file1byte" is 
                    // equal to "file2byte" at this point only if the files are 
                    // the same.
                    return ((file1byte - file2byte) == 0);
                }
            }
        }

        /// <summary>
        /// Create a directory if it does not already exist
        /// </summary>
        /// <param name="directory"></param>
        /// <remarks>NEW in v1.0.0.10</remarks>
        public static void EnsureDirectoryExists(string directory)
        {
            if (string.IsNullOrEmpty(directory)) throw new ArgumentNullException("ERROR: directory is required");

            if(Directory.Exists(directory) == false)
            {
                Directory.CreateDirectory(directory);
            }

        }

        #region Copy Files

        /// <summary>
        /// Copy files from one directory to another using a wildcard such as *
        /// </summary>
        /// <param name="sourceDirectory"></param>
        /// <param name="destinationDirectory"></param>
        /// <param name="fileNameWithWildCards"></param>
        /// <remarks>Adapted from StackExchange answer https://stackoverflow.com/questions/1835578/c-sharp-copying-multiple-files-with-wildcards-and-keeping-file-names 
        /// NEW in v1.0.0.17 - defaults to not overwriting
        /// </remarks>
        public static void CopyFiles(string sourceDirectory, string destinationDirectory, string fileNameWithWildCards)
        {
            if (string.IsNullOrEmpty(sourceDirectory)) throw new ArgumentNullException(nameof(sourceDirectory));
            if (string.IsNullOrEmpty(destinationDirectory)) throw new ArgumentNullException(nameof(destinationDirectory));

            CopyFiles(sourceDirectory, destinationDirectory, fileNameWithWildCards, false);
        }

        /// <summary>
        /// Copy files from one directory to another using a wildcard such as *
        /// </summary>
        /// <param name="sourceDirectory"></param>
        /// <param name="destinationDirectory"></param>
        /// <param name="fileNameWithWildCards"></param>
        /// <param name="overwrite">If true, existing files will be overwritten</param>
        /// <remarks>Adapted from StackExchange answer https://stackoverflow.com/questions/1835578/c-sharp-copying-multiple-files-with-wildcards-and-keeping-file-names 
        /// NEW in v1.0.0.18 - Allows for overwrite</remarks>
        public static void CopyFiles(string sourceDirectory, string destinationDirectory, string fileNameWithWildCards, bool overwrite)
        {
            if (string.IsNullOrEmpty(sourceDirectory)) throw new ArgumentException(nameof(sourceDirectory));
            if (string.IsNullOrEmpty(destinationDirectory)) throw new ArgumentException(nameof(destinationDirectory));

            var fileNames = Directory.GetFiles(sourceDirectory, fileNameWithWildCards);

            foreach (var fileName in fileNames)
            {
                var sourceFile = new FileInfo(fileName);
                sourceFile.CopyTo(EnsureTrailingDirectorySeparator(destinationDirectory) + fileName.Replace(sourceDirectory, string.Empty), overwrite);
            }
        }

        #endregion

        #region Copy Directory

        /// <summary>
        /// Copies a directory 
        /// </summary>
        /// <param name="sourceFullPath">Full path to directory to copy from</param>
        /// <param name="destinationFullPath">Full path to copy directory to</param>
        /// <remarks>NEW in v1.0.0.17 - assumes not overwriting</remarks>
        public static void CopyDirectory(string sourceFullPath, string destinationFullPath)
        {
            if (string.IsNullOrEmpty(sourceFullPath)) throw new ArgumentNullException("ERROR: sourceFullPath is required");
            if (string.IsNullOrEmpty(destinationFullPath)) throw new ArgumentNullException("ERROR: destinationFullPath is required");

            CopyDirectory(sourceFullPath, destinationFullPath, false, false);
        }

        /// <summary>
        /// Copies a directory 
        /// </summary>
        /// <param name="sourceFullPath">Full path to directory to copy from</param>
        /// <param name="destinationFullPath">Full path to copy directory to</param>
        /// <param name="overwrite">If true, existing files will be overwritten</param>
        /// <param name="ignoreFileExistErrorIfNotOverwriting">If overwrite = false and this is true it will simply skip copying the file if it exists but not throw an error</param>
        /// <remarks>NEW in v1.0.0.18 - Allows for overwrite
        ///     v8.0.0.0 - If not overwriting now allows to skip file rather than throwing an error for it existing
        /// </remarks>
        public static void CopyDirectory(string sourceFullPath, string destinationFullPath, bool overwrite, bool ignoreFileExistErrorIfNotOverwriting)
        {
            if (string.IsNullOrEmpty(sourceFullPath)) throw new ArgumentNullException(nameof(sourceFullPath));
            if (string.IsNullOrEmpty(destinationFullPath)) throw new ArgumentNullException(nameof(destinationFullPath));

            var sourceDir = new DirectoryInfo(sourceFullPath);
            var destinationDir = new DirectoryInfo(destinationFullPath);

            CopyDirectory(sourceDir, destinationDir, overwrite, ignoreFileExistErrorIfNotOverwriting);
        }

        /// <summary>
        /// Copies a directory 
        /// </summary>
        /// <param name="source">Directory to copy from</param>
        /// <param name="destination">Directory to</param>
        /// <remarks>NEW in v1.0.0.17 - assumes not overwriting</remarks>
        public static void CopyDirectory(DirectoryInfo source, DirectoryInfo destination)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            if (destination == null) throw new ArgumentNullException(nameof(destination));

            CopyDirectory(source, destination, false, false);
        }

        /// <summary>
        /// Copies a directory
        /// </summary>
        /// <param name="source">Directory to copy from</param>
        /// <param name="destination">Directory to</param>
        /// <param name="overwrite">If true, existing files will be overwritten</param>
        /// <param name="ignoreFileExistErrorIfNotOverwriting">If overwrite = false and this is true it will simply skip copying the file if it exists but not throw an error</param>
        /// <remarks>
        ///     NEW in v1.0.0.17 - Allows for overwrite
        ///     v8.0.0.0 - If not overwriting now allows to skip file rather than throwing an error for it existing
        /// </remarks>
        public static void CopyDirectory(DirectoryInfo source, DirectoryInfo destination, bool overwrite, bool ignoreFileExistErrorIfNotOverwriting)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            if (destination == null) throw new ArgumentNullException(nameof(destination));

            if (!destination.Exists)
            {
                destination.Create();
            }

            // Copy all files.
            var files = source.GetFiles();
            foreach (var file in files)
            {
                // if we are ignoring those that already exist
                if(overwrite == false && ignoreFileExistErrorIfNotOverwriting == true && File.Exists(Path.Combine(destination.FullName, file.Name)))
                { 
                    continue; 
                }   

                // Copy the file
                file.CopyTo(Path.Combine(destination.FullName, file.Name), overwrite);
            }

            // Process subdirectories.
            var dirs = source.GetDirectories();
            foreach (var dir in dirs)
            {
                // Get destination directory.
                var destinationDirectory = Path.Combine(destination.FullName, dir.Name);

                // Call CopyDirectory() recursively.
                CopyDirectory(dir, new DirectoryInfo(destinationDirectory), overwrite, ignoreFileExistErrorIfNotOverwriting);
            }
        }

        #endregion

        #region GetSubDirectories 

        /// <summary>NOTE: Could be replaced with System.ID.Directory.GetDirectories() if all you need is the directory name
        /// returns a list of directories beneath a given directory
        /// </summary>
        /// <param name="directoryFullPath">Absolute path to the directory</param>
        /// <returns></returns>
        public static DirectoryInfo[] GetSubDirectories(string directoryFullPath)
        {
            if (string.IsNullOrEmpty(directoryFullPath)) throw new ArgumentNullException(nameof(directoryFullPath));

            var source = new DirectoryInfo(directoryFullPath);
            return source.GetDirectories();
        }

        #endregion

        /// <summary>
        /// Directory Separator (may be different depending on operation system
        /// </summary>
        /// <remarks>V1.0.0.2 - Proper Case now used</remarks>
        public const string DirectorySeparator = @"\";

        #region FilePath Parsing Related

        /// <summary>
        /// Returns the originally passed in directoryPath but includes Directory seperator if not already at the end.
        /// </summary>
        /// <param name="directoryPath">Full path to directory</param>
        /// <returns>Directory with a slash on the end</returns>
        /// <remarks>NEW IN 1.0.0.1</remarks>
        public static string EnsureTrailingDirectorySeparator(string directoryPath)
        {
            if (string.IsNullOrEmpty(directoryPath)) throw new ArgumentNullException(nameof(directoryPath));

            return directoryPath + (directoryPath.EndsWith(DirectorySeparator) ? string.Empty : DirectorySeparator);
        }

        /// <summary>
        /// Converts a local absolute file path to Uri
        /// </summary>
        /// <param name="absoluteFilePath"></param>
        /// <returns></returns>
        public static Uri ConvertAbsoluteFilePathToUri(string absoluteFilePath)
        {
            if (string.IsNullOrEmpty(absoluteFilePath)) throw new ArgumentNullException(nameof(absoluteFilePath));

            return new Uri(absoluteFilePath, UriKind.Absolute);
        }

        /// <summary>
        /// Converts local Uri to Absolute File Path
        /// </summary>
        /// <param name="localUri"></param>
        /// <returns></returns>
        /// <remarks>New In v1.0.0.9</remarks>
        public static string ConvertLocalUriToAbsoluteFilePath(Uri localUri)
        {
            if (localUri == null) throw new ArgumentNullException(nameof(localUri));

            string localFilePath = localUri.LocalPath;
            if (localFilePath.StartsWith("\\")) throw new Exception("ConvertLocalUriToAbsoluteFilePath - ERROR: Local Uri is not actual local Uri (" + localFilePath  + ")");

            return localFilePath;
        }

        /// <summary>
        /// Returns Directory Portion of FullPath
        /// </summary>
        /// <param name="fullPath">full path to a file</param>
        /// <returns>Directory portion of file path</returns>
        /// <remarks>Fixed in v1.0.0.11 - Did not return the drive portion</remarks>
        public static string GetDirectoryFromFilePath(string fullPath)
        {
            if (string.IsNullOrEmpty(fullPath)) throw new ArgumentNullException(nameof(fullPath));

            var fileParts = fullPath.Split(DirectorySeparator[0]);

            // (FIXED in v1.0.0.11) if fileparts > 0 then we need to append the first part
            var fileDirectory = (fileParts.Length > 0) ? fileParts[0] : string.Empty;

            for (var partNdx = 1; partNdx < fileParts.Length - 1; partNdx++)
            {
                fileDirectory = fileDirectory + DirectorySeparator + fileParts[partNdx];
            }

            return fileDirectory;
        }

        /// <summary>
        /// Returns Last DirectoryFolderName from of DirectoryPath
        /// </summary>
        /// <param name="fullPath">full path to a directory folder</param>
        /// <returns>Directory folder name from full path</returns>
        public static string GetDirectoryFolderNameFromDirectoryPath(string fullPath)
        {
            if (string.IsNullOrEmpty(fullPath)) throw new ArgumentNullException(nameof(fullPath));

            var fileParts = fullPath.Split(DirectorySeparator[0]);
            return fileParts.Length > 0 ? fileParts[fileParts.Length - 1] : "";
        }

        /// <summary>
        /// Returns FileName Portion of FullPath
        /// </summary>
        /// <param name="fullPath">full path to a file</param>
        /// <returns>Filename from full path</returns>
        public static string GetFileNameFromFilePath(string fullPath)
        {
            if (string.IsNullOrEmpty(fullPath)) throw new ArgumentNullException(nameof(fullPath));

            var fileParts = fullPath.Split(DirectorySeparator[0]);
            return fileParts.Length > 0 ? fileParts[fileParts.Length - 1] : "";
        }

        #endregion

        #region File List for Directory 

        /// <summary>
        /// Returns a list of FileInfo for files in a given directory
        /// </summary>
        /// <param name="fileSystemDirectoryPath">Full path to directory containing the files</param>
        /// <returns>An array of FileInfo object for each file in the directory</returns>
        public static FileInfo [] GetFileListForDirectory(string fileSystemDirectoryPath)
        {
            if (string.IsNullOrEmpty(fileSystemDirectoryPath)) throw new ArgumentNullException(nameof(fileSystemDirectoryPath));

            // Get the list of files
            var di = new DirectoryInfo(fileSystemDirectoryPath);
            return di.GetFiles();
        }

        /// <summary>
        /// Returns a list of FileInfo for files in a given directory
        /// </summary>
        /// <param name="fileSystemDirectoryPath">Full path to directory containing the files</param>
        /// <param name="searchPattern">Filter used to determine which files get returned</param>
        /// <param name="recursive">If true, returns all files for all subdirectories as well</param>
        /// <returns>An array of FileInfo object for each file in the directory matching the filter</returns>
        public static FileInfo[] GetFilteredFileListForDirectory(string fileSystemDirectoryPath, string searchPattern, bool recursive)
        {
            if (string.IsNullOrEmpty(fileSystemDirectoryPath)) throw new ArgumentNullException(nameof(fileSystemDirectoryPath));

            // Get the list of files
            var di = new DirectoryInfo(fileSystemDirectoryPath);
            return di.GetFiles(searchPattern, recursive ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly);
        }
        
        #endregion

        /// <summary>
        /// Returns true if file size is greater than maximum file size
        /// </summary>
        /// <param name="fileInfo">File Information Object</param>
        /// <param name="maxFileSize">Maximum File Size</param>
        /// <returns>True, if the file size is greater than the max file size passed in</returns>
        /// <remarks>NEW IN V1.0.0.4</remarks>
        public static bool IsFileOverMaxSize(FileInfo fileInfo, long maxFileSize)
        {
            return fileInfo.Length < maxFileSize;
        }
    }
}
