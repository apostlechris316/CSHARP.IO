﻿/********************************************************************************
 * CSHARP IO Library - General utility to manipulate files in on the Windows 
 * file system 
 * 
 * NOTE: Adapted from Clinch.IO
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 *
 * CHANGES: 
 * 
 *  (v5.0) 
 *      - Namespace changed to contain version for future backwards compatability.
 *      - All methods converted to static
 *  (v8.0) 
 *      - CopyDirectory introduces ignoreFileExistErrorIfNotOverwriting. If not overwriting now allows to skip file rather than throwing an error for it existing
 *      
 *  
 * FUTURE IMPROVEMENTS:
 * 
 ********************************************************************************/

namespace CSHARP.V8.Helpers.IO
{
    using System;
    using System.Collections.Generic;
    using System.IO;

    /// <summary>
    /// C# Class containing Static Methods to help working with files and file paths.
    /// </summary>
    public class FileHelper
    {
        /// <summary>
        /// Look at all files in a given folder to see if they could have been new or edited.
        /// </summary>
        /// <param name="firstFolder">The full path to folder to compare</param>
        /// <param name="secondFolder">The full path to the folder you want compared with the firstFolder</param>
        /// <param name="recursive">Checks all subdirectories in both folders against each other</param>
        /// <param name="checkContents">If selected compares the actual contents of the file if the lengths match otherwise just does quick check of date, file meta and size check.</param>
        /// <returns></returns>
        /// <remarks> NEW IN v1.0.0.13
        /// If you pass checkContents of false, then the results may not be totally accurrate
        /// v1.0.1.0 
        ///     - Bug Fix on checkContents boolean it was using reverse logic. This is now resovled so you will need to resolve your code.
        ///     - Now checks subdirectories if recursive = true
        /// </remarks>
        public Dictionary<FileInfo, string> GetPossibleNewOrEditedFilesInFolders(string firstFolder, string secondFolder, bool recursive, bool checkContents)
        {
            return FileHelperStatic.GetPossibleNewOrEditedFilesInFolders(firstFolder, secondFolder, recursive, checkContents);
        }

        /// <summary>
        /// Compares two files to see if they are equal
        /// </summary>
        /// <param name="firstFilePath">Path to the first file to compare</param>
        /// <param name="secondFilePath">Path to the second file to compare</param>
        /// <returns></returns>
        /// <remarks> NEW IN v1.0.0.13
        public bool FileCompare(string firstFilePath, string secondFilePath)
        {
            return FileCompare(firstFilePath, secondFilePath);
        }

        /// <summary>
        /// Create a directory if it does not already exist
        /// </summary>
        /// <param name="directory"></param>
        /// <remarks>NEW in v1.0.0.10</remarks>
        public void EnsureDirectoryExists(string directory)
        {
            EnsureDirectoryExists(directory);
        }

        #region Copy Files

        /// <summary>
        /// Copy files from one directory to another using a wildcard such as *
        /// </summary>
        /// <param name="sourceDirectory"></param>
        /// <param name="destinationDirectory"></param>
        /// <param name="fileNameWithWildCards"></param>
        /// <remarks>Adapted from StackExchange answer https://stackoverflow.com/questions/1835578/c-sharp-copying-multiple-files-with-wildcards-and-keeping-file-names 
        /// NEW in v1.0.0.17 - defaults to not overwriting
        /// </remarks>
        public void CopyFiles(string sourceDirectory, string destinationDirectory, string fileNameWithWildCards)
        {
            FileHelperStatic.CopyFiles(sourceDirectory, destinationDirectory, fileNameWithWildCards);
        }

        /// <summary>
        /// Copy files from one directory to another using a wildcard such as *
        /// </summary>
        /// <param name="sourceDirectory"></param>
        /// <param name="destinationDirectory"></param>
        /// <param name="fileNameWithWildCards"></param>
        /// <param name="overwrite">If true, existing files will be overwritten</param>
        /// <remarks>Adapted from StackExchange answer https://stackoverflow.com/questions/1835578/c-sharp-copying-multiple-files-with-wildcards-and-keeping-file-names 
        /// NEW in v1.0.0.18 - Allows for overwrite</remarks>
        public void CopyFiles(string sourceDirectory, string destinationDirectory, string fileNameWithWildCards, bool overwrite)
        {
            FileHelperStatic.CopyFiles(sourceDirectory, destinationDirectory, fileNameWithWildCards, overwrite);        
        }

        #endregion

        #region Copy Directory

        /// <summary>
        /// Copies a directory 
        /// </summary>
        /// <param name="sourceFullPath">Full path to directory to copy from</param>
        /// <param name="destinationFullPath">Full path to copy directory to</param>
        /// <remarks>NEW in v1.0.0.17 - assumes not overwriting</remarks>
        public void CopyDirectory(string sourceFullPath, string destinationFullPath)
        {
            FileHelperStatic.CopyDirectory(sourceFullPath, destinationFullPath);
        }

        /// <summary>
        /// Copies a directory 
        /// </summary>
        /// <param name="sourceFullPath">Full path to directory to copy from</param>
        /// <param name="destinationFullPath">Full path to copy directory to</param>
        /// <param name="overwrite">If true, existing files will be overwritten</param>
        /// <param name="ignoreFileExistErrorIfNotOverwriting">If overwrite = false and this is true it will simply skip copying the file if it exists but not throw an error</param>
        /// <remarks>NEW in v1.0.0.18 - Allows for overwrite
        ///     v8.0.0.0 - If not overwriting now allows to skip file rather than throwing an error for it existing
        /// </remarks>
        public void CopyDirectory(string sourceFullPath, string destinationFullPath, bool overwrite, bool ignoreFileExistErrorIfNotOverwriting)
        {
            FileHelperStatic.CopyDirectory(sourceFullPath, destinationFullPath, overwrite, ignoreFileExistErrorIfNotOverwriting);
        }

        /// <summary>
        /// Copies a directory 
        /// </summary>
        /// <param name="source">Directory to copy from</param>
        /// <param name="destination">Directory to</param>
        /// <remarks>NEW in v1.0.0.17 - assumes not overwriting</remarks>
        public void CopyDirectory(DirectoryInfo source, DirectoryInfo destination)
        {
            FileHelperStatic.CopyDirectory(source, destination);
        }

        /// <summary>
        /// Copies a directory
        /// </summary>
        /// <param name="source">Directory to copy from</param>
        /// <param name="destination">Directory to</param>
        /// <param name="overwrite">If true, existing files will be overwritten</param>
        /// <param name="ignoreFileExistErrorIfNotOverwriting">If overwrite = false and this is true it will simply skip copying the file if it exists but not throw an error</param>
        /// <remarks>
        ///     NEW in v1.0.0.17 - Allows for overwrite
        ///     v8.0.0.0 - If not overwriting now allows to skip file rather than throwing an error for it existing
        /// </remarks>
        public void CopyDirectory(DirectoryInfo source, DirectoryInfo destination, bool overwrite, bool ignoreFileExistErrorIfNotOverwriting)
        {
            FileHelperStatic.CopyDirectory(source, destination, overwrite, ignoreFileExistErrorIfNotOverwriting);
        }

        #endregion

        #region GetSubDirectories 

        /// <summary>
        /// returns a list of directories beneath a given directory
        /// </summary>
        /// <param name="directoryFullPath"></param>
        /// <returns></returns>
        public DirectoryInfo[] GetSubDirectories(string directoryFullPath)
        {
            return FileHelperStatic.GetSubDirectories(directoryFullPath);
        }

        #endregion

        /// <summary>
        /// Directory Separator (may be different depending on operation system
        /// </summary>
        /// <remarks>V1.0.0.2 - Proper Case now used</remarks>
        public const string DirectorySeparator = @"\";

        #region FilePath Parsing Related

        /// <summary>
        /// Returns the originally passed in directoryPath but includes Directory seperator if not already at the end.
        /// </summary>
        /// <param name="directoryPath">Full path to directory</param>
        /// <returns>Directory with a slash on the end</returns>
        /// <remarks>NEW IN 1.0.0.1</remarks>
        public string EnsureTrailingDirectorySeparator(string directoryPath)
        {
            return FileHelperStatic.EnsureTrailingDirectorySeparator(directoryPath);
        }

        /// <summary>
        /// Converts a local absolute file path to Uri
        /// </summary>
        /// <param name="absoluteFilePath"></param>
        /// <returns></returns>
        public Uri ConvertAbsoluteFilePathToUri(string absoluteFilePath)
        {
            return FileHelperStatic.ConvertAbsoluteFilePathToUri(absoluteFilePath);
        }

        /// <summary>
        /// Converts local Uri to Absolute File Path
        /// </summary>
        /// <param name="localUri"></param>
        /// <returns></returns>
        /// <remarks>New In v1.0.0.9</remarks>
        public string ConvertLocalUriToAbsoluteFilePath(Uri localUri)
        {
            return FileHelperStatic.ConvertLocalUriToAbsoluteFilePath(localUri);
        }

        /// <summary>
        /// Returns Directory Portion of FullPath
        /// </summary>
        /// <param name="fullPath">full path to a file</param>
        /// <returns>Directory portion of file path</returns>
        /// <remarks>Fixed in v1.0.0.11 - Did not return the drive portion</remarks>
        public string GetDirectoryFromFilePath(string fullPath)
        {
            return FileHelperStatic.GetDirectoryFromFilePath(fullPath);
        }

        /// <summary>
        /// Returns Last DirectoryFolderName from of DirectoryPath
        /// </summary>
        /// <param name="fullPath">full path to a directory folder</param>
        /// <returns>Directory folder name from full path</returns>
        public string GetDirectoryFolderNameFromDirectoryPath(string fullPath)
        {
            return FileHelperStatic.GetDirectoryFolderNameFromDirectoryPath(fullPath);
        }

        /// <summary>
        /// Returns FileName Portion of FullPath
        /// </summary>
        /// <param name="fullPath">full path to a file</param>
        /// <returns>Filename from full path</returns>
        public string GetFileNameFromFilePath(string fullPath)
        {
            return FileHelperStatic.GetFileNameFromFilePath(fullPath);
        }

        #endregion

        #region File List for Directory 

        /// <summary>
        /// Returns a list of FileInfo for files in a given directory
        /// </summary>
        /// <param name="fileSystemDirectoryPath">Full path to directory containing the files</param>
        /// <returns>An array of FileInfo object for each file in the directory</returns>
        public FileInfo [] GetFileListForDirectory(string fileSystemDirectoryPath)
        {
            return FileHelperStatic.GetFileListForDirectory(fileSystemDirectoryPath);
        }

        /// <summary>
        /// Returns a list of FileInfo for files in a given directory
        /// </summary>
        /// <param name="fileSystemDirectoryPath">Full path to directory containing the files</param>
        /// <param name="searchPattern">Filter used to determine which files get returned</param>
        /// <param name="recursive">If true, returns all files for all subdirectories as well</param>
        /// <returns>An array of FileInfo object for each file in the directory matching the filter</returns>
        public FileInfo[] GetFilteredFileListForDirectory(string fileSystemDirectoryPath, string searchPattern, bool recursive)
        {
            return FileHelperStatic.GetFilteredFileListForDirectory(fileSystemDirectoryPath, searchPattern, recursive);
        }
        
        #endregion

        /// <summary>
        /// Returns true if file size is greater than maximum file size
        /// </summary>
        /// <param name="fileInfo">File Information Object</param>
        /// <param name="maxFileSize">Maximum File Size</param>
        /// <returns>True, if the file size is greater than the max file size passed in</returns>
        /// <remarks>NEW IN V1.0.0.4</remarks>
        public bool IsFileOverMaxSize(FileInfo fileInfo, long maxFileSize)
        {
            return FileHelperStatic.IsFileOverMaxSize(fileInfo, maxFileSize);
        }
    }
}
