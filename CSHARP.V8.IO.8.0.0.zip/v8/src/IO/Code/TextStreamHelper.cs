﻿/********************************************************************************
 * CSHARP IO Library - General utility to manipulate files in on the Windows 
 * file system 
 * 
 * NOTE: Adapted from Clinch.IO
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 ********************************************************************************/

namespace CSHARP.V8.Helpers.IO
{
    using System.IO;

    /// <summary>
    /// Text Stream Helper Functions
    /// </summary>
    public class TextStreamHelper
    {
        /// <summary>
        /// Reads the full contents of the file to a string
        /// </summary>
        /// <param name="fileInfo">FileInfo object used to open the stream for read</param>
        /// <returns>Contents of the stream in a string</returns>
        /// <remarks>NEW in v1.0.0.9</remarks>
        public string ReadContents(FileInfo fileInfo)
        {
            return TextStreamHelperStatic.ReadContents(fileInfo);
        }
        /// <summary>
        /// Reads the full contents of the file to a string
        /// </summary>
        /// <param name="stream">Stream to get contents from</param>
        /// <returns>Contents of the stream in a string</returns>
        /// <remarks>Beware as stream passsed in is passed to StreamReader so likely it will be disposed when returned</remarks>
        public string ReadContents(Stream stream)
        {
            return TextStreamHelperStatic.ReadContents(stream);
        }

        /// <summary>
        /// Writes the contents supplied to a file. (Always Overwrites the file. If you wish to append use WriteContents with file path)
        /// </summary>
        /// <param name="fileInfo">FileInfo object used to open the stream for write</param>
        /// <param name="contents">contents to write</param>
        /// <remarks>NEW in v1.0.0.9</remarks>
        public void WriteContents(FileInfo fileInfo, string contents)
        {
            TextStreamHelperStatic.WriteContents(fileInfo, contents);
        }

        /// <summary>
        /// Writes the contents supplied to a file.
        /// </summary>
        /// <param name="fileName">file to write contents to</param>
        /// <param name="contents">contents to write</param>
        /// <param name="overwrite">if true overwrites existing file else appends to end</param>
        /// <remarks>Beware as stream passsed in is passed to StreamWriter so likely it will be disposed when returned</remarks>
        public void WriteContents(string fileName, string contents, bool overwrite)
        {
            TextStreamHelperStatic.WriteContents(fileName, contents, overwrite);
        }
    } 
}
