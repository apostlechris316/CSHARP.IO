# CSHARP.V8.Helpers.IO

This QuickStart assists in manipulating files

## Getting started

Using the Nuget is simple. Most classes have a static and non-static version the non-static one calls the static one so the code is the same.
The non-static exist so Powershell can more easily make use of the methods.  

BinaryFileHelper: This reads/writes a binary file
FileHelper: This helps with getting/copying files on the filesystem. These are thin wrappaers around the System.IO.File/Directory functions.
TextFileHelper: This reads/writes a text file
TextStreamHelper: This reads/writes a text stream

### Prerequisites

This library only relies on the standard .NET 8.0 calls.

## Usage

## Additional documentation

Provide links to more resources: List links such as detailed documentation, tutorial videos, blog posts, or any other relevant documentation to help users get the most out of your package.

## Feedback

If you have any questions or have feedback email me at chris.williams@readwatchcreate.com