﻿/********************************************************************************
 * CSHARP IO Library - General utility to manipulate files in on the Windows 
 * file system 
 * 
 * NOTE: Adapted from Clinch.IO
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 ********************************************************************************/

namespace CSHARP.V8.Helpers.IO
{
    using System;
    using System.IO;
    using System.Text;

    /// <summary>
    /// Text File Helper Functions
    /// </summary>
    /// <remarks>All methods converted to </remarks>
    public class TextFileHelper
    {
        /// <summary>
        /// Opens the input file stream
        /// </summary>
        /// <param name="fileName">Full path to file</param>
        /// <returns>Stream to read from</returns>
        /// <remarks>NEW in V1.0.0.5
        /// V1.0.0.7 - Notice that CloseInputFileStream was removed.  Use "Using" instead as it will handle Close and Dispose automatically for you. 
        /// </remarks>
        public StreamReader OpenInputFileStream(string fileName)
        {
            return TextFileHelperStatic.OpenInputFileStream(fileName);
        }

        /// <summary>
        /// Gets the line count for a single file (even blank ones)
        /// </summary>
        /// <param name="fileName">Full path to the file to count lines</param>
        /// <returns></returns>
        /// <remarks>
        /// NEW in v1.0.0.15
        /// </remarks>
        public int GetLineCount(string fileName)
        {
            return TextFileHelperStatic.GetLineCount(fileName);
        }

        /// <summary>
        /// Gets the line count for a single file
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="ignoreBlankLines">If true, will only count lines with text</param>
        /// <returns></returns>
        /// <remarks>
        /// NEW in v1.0.0.15
        /// Ported from https://www.codeproject.com/Articles/9105/Counting-Lines-of-Code-in-C to .NET Standard Library
        /// </remarks>
        public int GetLineCount(string fileName, bool ignoreBlankLines)
        {
            return TextFileHelperStatic.GetLineCount(fileName, ignoreBlankLines);
        }

        /// <summary>
        /// Reads the full contents of the file to a string
        /// </summary>
        /// <param name="fileName">name of file to get contents from</param>
        /// <returns>full contents of the file as a string</returns>
        /// <remarks>v1.0.0.7 Converted to using and removed redundant Close and Dispose</remarks>
        public string ReadContents(string fileName)
        {
            return TextFileHelperStatic.ReadContents(fileName);
        }

        /// <summary>
        /// Reads the full contents of the file to a string using specific encoding
        /// </summary>
        /// <param name="fileName">name of file to get contents from</param>
        /// <param name="encoding"></param>
        /// <returns>full contents of the file as a string</returns>
        /// <remarks>v1.0.0.7 Converted to using and removed redundant Close and Dispose<br/>
        /// v1.0.0.8 Now supports passing in encoding</remarks>
        public string ReadContents(string fileName, string encoding)
        {
            return TextFileHelperStatic.ReadContents(fileName, encoding);
        }

        /// <summary>
        /// Writes the contents supplied to a file.
        /// </summary>
        /// <param name="fileName">file to write contents to</param>
        /// <param name="contents">contents to write</param>
        /// <param name="overwrite">if true overwrites existing file else appends to end</param>
        /// <remarks>v1.0.0.7 Converted to using and removed redundant Close and Dispose.
        /// v1.0.0.12 Optimized by getting directory path once instead of twice</remarks>
        public void WriteContents(string fileName, string contents, bool overwrite)
        {
            TextFileHelperStatic.WriteContents(fileName, contents, overwrite);
        }

        /// <summary>
        /// Writes the contents supplied to a file.
        /// </summary>
        /// <param name="fileName">file to write contents to</param>
        /// <param name="contents">contents to write</param>
        /// <param name="overwrite">if true overwrites existing file else appends to end</param>
        /// <param name="encoding">Determines how contents is encoded on write possible values are (ASCII,UTF7,UTF8,UTF32, or empty string). If empty string it uses the default encoding.</param>
        /// <remarks>NEW in v1.0.0.8 </remarks>
        public void WriteContents(string fileName, string contents, bool overwrite, string encoding)
        {
            TextFileHelperStatic.WriteContents(fileName , contents, overwrite, encoding);
        }

        /// <summary>
        /// Opens a file, replaces a string with another string then saves the file
        /// </summary>
        /// <param name="fileName">Full path to file</param>
        /// <param name="find">Text to find</param>
        /// <param name="replace">Text to replace</param>
        /// <remarks>NEW in 1.0.0.8 </remarks>
        public void ReplaceInFile(string fileName, string find, string replace)
        {
            TextFileHelperStatic.ReplaceInFile(fileName, find, replace);
        }
    }
}