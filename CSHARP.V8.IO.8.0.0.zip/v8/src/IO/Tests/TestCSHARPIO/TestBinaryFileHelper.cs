using CSHARPStandard.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestCSHARPStandardIO
{
    [TestClass]
    public class TestBinaryFileHelper
    {
        [TestMethod]
        public void TestReadStreamEmptyFilename()
        {
            var binaryFileHelper = new BinaryFileHelper();
            binaryFileHelper.ReadStream(string.Empty);
        }
        [TestMethod]
        public void TestReadStream()
        {
            var binaryFileHelper = new BinaryFileHelper();
            var stream = binaryFileHelper.ReadStream("c:\\binaryTest.bin");
            stream.Close();
            stream.Dispose();
            stream = null;
        }

        [TestMethod]
        public void TestReadContentsEmptyFilename()
        {
            var binaryFileHelper = new BinaryFileHelper();
            binaryFileHelper.ReadContents(string.Empty);
        }

        [TestMethod]
        public void TestReadContents()
        {
            var binaryFileHelper = new BinaryFileHelper();
            var content = binaryFileHelper.ReadContents("c:\\binaryTest.bin");
        }

        [TestMethod]
        public void TestWriteContentsEmptyFilename()
        {
            var binaryFileHelper = new BinaryFileHelper();
            binaryFileHelper.WriteContents(string.Empty, null);
        }

        [TestMethod]
        public void TestWriteContentsNullByteArray()
        {
            var binaryFileHelper = new BinaryFileHelper();
            binaryFileHelper.WriteContents("c:\\binaryTest.bin", null);
        }
    }
}
